package Module1;

public class Myclass2 {

	public static void main(String[] args) {
		int empno=100;
		String ename="Manish B";
		double sal=30000.50;
		float comm=1000.66f;
		float bonus=(float)500.55;
		byte b=100;
		short s=2000;
		long l=7987984654l;
		char gender='m';
		boolean passStatus=true;
		
		System.out.println("empno is "+ empno);
		System.out.println("ename is "+ ename);
		System.out.println("salary is "+ sal);
		System.out.println("comm is "+ comm);
		System.out.println("bonus is "+ bonus);

	}

}
