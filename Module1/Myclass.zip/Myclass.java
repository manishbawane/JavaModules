package Module1;

public class Myclass {

	public static void main(String[] args) {
		System.out.println("Manish Bawane");
		System.out.println("CDAC");
	}

}
